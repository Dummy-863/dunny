import {
    cart , removeFromCart
} from '../data/cart.js';

import{
  products
} from '../data/products.js';

import{
  formatCurrency
}from '../utils/money.js'

let totalPrice = 0;
let shippingCharge = 0;



function getPrice(){
	totalPrice = 0;
	for(var i=0; i<cart.length ; i++){
		//console.log(cart[i]);
		totalPrice += (cart[i].quantity * cart[i].priceCents);
	}

  totalPrice+=shippingCharge;

	let priceHTML = `$${formatCurrency(totalPrice)}`;

	document.querySelector('.payment-summary-money').innerHTML=priceHTML;

  document.querySelector('.shipping-charge').innerHTML=`$${formatCurrency(shippingCharge)}`;

	document.querySelector('.sub-total').innerHTML = priceHTML;

	let tax = totalPrice*0.1;

	priceHTML = `$${formatCurrency(tax)}`;

	document.querySelector('.total-tax').innerHTML=priceHTML;

	let total = formatCurrency(totalPrice*1.1);

	priceHTML = `$${total}`;

	document.querySelector('.total-sum').innerHTML=priceHTML;

	document.querySelector('.item-count').innerHTML=`Items (${cart.length}) :`;

  document.querySelector('.item-header').innerHTML=`${cart.length} Items`;
	
}

getPrice();

//console.log(formatCurrency(totalPrice));
//console.log(cart);




let cartHTML = '';

cart.forEach((item)=> {


	let matchingProduct;
	let k=0;

	//console.log(item.productID);
	//console.log(item);

	products.forEach((product) => {
		//console.log(item.productID);
		if(item.productID == product.id){
			matchingProduct=product;
			k=1;
		}
	});
	//console.log(matchingProduct);


	if(k)cartHTML += `
	
					<div class="cart-item-container js-cart-item-container-${matchingProduct.id}">
						<div class="delivery-date">
							Delivery date: Tuesday, June 21
						</div>

						<div class="cart-item-details-grid">
							<img class="product-image"
								src="${matchingProduct.image}">

							<div class="cart-item-details">
								<div class="product-name">
									${matchingProduct.name}
								</div>
								<div class="product-price">
									$${formatCurrency(matchingProduct.priceCents)}
								</div>
								<div class="product-quantity">
									<span>
										Quantity: <span class="quantity-label">${item.quantity}</span>
									</span>
									<span class="update-quantity-link link-primary">
										Update
									</span>
									<span class="delete-quantity-link link-primary js-delete-link" 
										data-product-id = "${matchingProduct.id}">

										Delete

									</span>
								</div>
							</div>

							<div class="delivery-options">
								<div class="delivery-options-title">
									Choose a delivery option:
								</div>
								<div class="delivery-option">
									<input type="radio" checked
										class="delivery-option-input"
										name="${matchingProduct.id}">
									<div>
										<div class="delivery-option-date">
											Tuesday, June 21
										</div>
										<div class="delivery-option-price">
											FREE Shipping
										</div>
									</div>
								</div>
								<div class="delivery-option">
									<input type="radio"
										class="delivery-option-input"
										name="${matchingProduct.id}">
									<div>
										<div class="delivery-option-date">
											Wednesday, June 15
										</div>
										<div class="delivery-option-price">
											$4.99 - Shipping
										</div>
									</div>
								</div>
								<div class="delivery-option">
									<input type="radio"
										class="delivery-option-input"
										name="${matchingProduct.id}">
									<div>
										<div class="delivery-option-date">
											Monday, June 13
										</div>
										<div class="delivery-option-price">
											$9.99 - Shipping
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
	
	
	
	
	
	
	
	
	
	
	`;
	


});

document.querySelector('.order-summary').innerHTML = cartHTML;


document.querySelectorAll('.js-delete-link').forEach((link) => {
	link.addEventListener('click',() => {
		const productId = link.dataset.productId;
		//console.log(productId);
		removeFromCart(productId);
		getPrice();
		const container = document.querySelector(
			`.js-cart-item-container-${productId}`
		);
		if(container !== null)container.remove();

	});


});




// Get all radio button groups
const deliveryOptionGroups = document.querySelectorAll('.delivery-options');

// Iterate over each group
deliveryOptionGroups.forEach(group => {
    // Get all radio buttons within the current group
    const radioButtons = group.querySelectorAll('.delivery-option-input');

    // Attach change event listener to each radio button
    radioButtons.forEach(radioButton => {
        radioButton.addEventListener('change', function() {
            // Check if the radio button is selected
            if (this.checked) {
                // Get the selected date and price
                const selectedDate = this.closest('.delivery-option').querySelector('.delivery-option-date').textContent.trim();
                const selectedPrice = this.closest('.delivery-option').querySelector('.delivery-option-price').textContent.trim();

                // Run the update function with selected date and price
                updateFunction(selectedDate, selectedPrice);
            }
        });
    });
});




// Update function to be executed when a radio button is selected
function updateFunction(date, price) {
    // Replace this with your update logic
    //console.log('Selected Date:', date);
    //console.log('Selected Price:', price);
    // You can perform further actions based on the selected date and price

    if(price === "FREE Shipping")shippingCharge+=0;
    else if(price === "$4.99 - Shipping")shippingCharge+=499;
    else if(price === "$9.99 - Shipping")shippingCharge+=999;

		shippingCharge=0;


    getPrice();
}
