import { products } from "./products.js";


//localStorage.clear();

export const cart = JSON.parse(localStorage.getItem('cart'));//||[{productID : "e43638ce-6aa0-4b85-b27f-e1d07eb678c6",quantity : 1,priceCents:1090}];



function saveToStorage(){
    localStorage.setItem('cart',JSON.stringify(cart));
}


export function addToCart(productId){

  let productPrice = 0;

  for(let i=0; i<products.length ; i++){
    if(productId === products[i].id)productPrice=products[i].priceCents;
  }


    let k = 1;
        let cartQuantity = 0;
        
        for(let i=0 ; i < cart.length ; i++){
          if(productId === cart[i].productID){
            cart[i].quantity += 1 ;
            k = 0;   
          }
  
          cartQuantity += cart[i].quantity;
  
        }
  
        if(k){
          cart.push({
          productID : productId , 
          quantity : 1 ,
          priceCents : productPrice
          });
          cartQuantity++;          
        }

        saveToStorage();
       
        document.querySelector('.cart-quantity').innerHTML = cartQuantity ;
     
  }

  export function removeFromCart(productId){

    for(let i=0;i<cart.length;i++){
        if(cart[i].productID === productId){
            cart.splice(i,1);
        }
    }
    saveToStorage();
  }